//
// Created by freak on 2/15/16.
//
#include "Element.h"

Element::Element() {

}
