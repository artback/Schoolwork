package com.project.farm;

public class Main {

    public static void main(String[] args) {
        Gui window = new Gui();
        window.CreateGui();
    }
}

