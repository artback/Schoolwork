package com.project.farm;

import javax.swing.*;

public class Pig extends Animals{
    Pig() {
        this.name = "Ronny";
        this.animal = "pig";
        button = new JButton(this.animal);
        this.sound = "/home/freak/Music/pig.wav";
    }
}
