package com.project.farm;

public class Sheep extends Animal{
 private String color;
 Sheep(String animal,String sound){
  super(animal,sound);
  this.color="white";
 }
}
