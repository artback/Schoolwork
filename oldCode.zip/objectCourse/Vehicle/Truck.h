//
// Created by freak on 2015-11-18.
//

#ifndef VEHICLE_TRUCK_H
#define VEHICLE_TRUCK_H


class Truck {

};


#endif //VEHICLE_TRUCK_H
