//
// Created by freak on 2015-11-18.
//

#include "Truck.h"
