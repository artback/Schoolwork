//
// Created by freak on 2015-11-18.
//

#ifndef VEHICLE_BOAT_H
#define VEHICLE_BOAT_H


class Boat {
public:
    Boat(int depth);
private:
    int depth;


};


#endif //VEHICLE_BOAT_H
