//
// Created by freak on 2015-11-18.
//

#include "Boat.h"

Boat::Boat(int depth) {
    this->depth=depth;
}
