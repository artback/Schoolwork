package com.project.farm;

public class Pig extends Animal{
    Pig(String animal,String sound){
        super(animal,sound);
    }
}
