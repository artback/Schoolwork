package com.project.farm;
// id, sommarbetestid

// gui -> farm -> animals
//                dog cow ...
// filhantering separat klass

public class Main {

    public static void main(String[] args) {
        Gui window = new Gui();
        window.init();
    }
}

